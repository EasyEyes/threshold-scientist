EasyEyes Demo

Dear colleague

EasyEyes offers an easy way to do online vision-testing experiments. First you design your experiment in a spreadsheet, simply assigning values to parameters, one per condition. EasyEyes is a compiler that converts your spreadsheet table into a web app for online vision testing. Currently it measures size and spacing thresholds, ie acuity and crowding, and reading speed and retention. It can measure spacing threshold with any font, anywhere in the visual field, radially or tangentially. It calibrates screen size and tracks viewing distance. It can also track gaze.

TEST YOURSELF OR SOMEONE YOU RECRUITED: 
1. Register for a (free) account at pavlovia.org
2. In your browser, go to http://easyeyes.app
3. Click EasyEyes button to log into Pavlovia.
4. Submit all the font and form files in this demo folder into the drop box in the EasyEyes screen.
5. Submit either of the demo experiments (demo...Experiment.xlsx) into the drop box. EasyEyes will compile, upload, and set RUNNING mode.
6. Run the experiment.
7. Hit the download data button on the Pavlovia page to get your results.
8. Edit the demo to make it do what you want. We think you'll find the compiler's error messages helpful. Currently EasyEyes only measures acuity, crowding, and reading. We plan to add contrast threshold. The main EasyEyes page links to the Manual and Parameter Glossary. Please only test participants after you've replaced our placeholder with your own IRB-approved consent form.

RECRUIT AND TEST ONLINE: 
You can use Prolific to recruit participants. Follow the steps above. Once your experiment is compiled, EasyEyes will offer you a button to take your experiment to Prolific. Prolific has a Preview mode that you can use, on yourself, for free. Please only test participants after you've replaced our placeholder with your own IRB-approved consent form.

Comments and questions are welcome. Please write to me at denis.pelli@nyu.edu with SUBJECT:EasyEyes.

Good luck!
Denis Pelli
May 29, 2022