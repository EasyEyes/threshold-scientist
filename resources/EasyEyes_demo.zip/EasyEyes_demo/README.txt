Easy Eyes Demo
1. Register for a (free) account at pavlovia.org
2. In your browser, go to http://easyeyes.app/threshold
3. Click the Pavlovia button and log in.
4. Drop all the font and form files in this demo folder onto the drop box in the EasyEyes screen.
5. Drop demoExperiment.xlsx onto the drop box.
5. Click the button to go to Pavlovia.
6. If you have a university license, then hit RUNNING and RUN. 
Otherwise hit PILOTING and PILOT, to avoid being charged by Pavlovia.

Good luck!
Denis Pelli
November 20, 2021