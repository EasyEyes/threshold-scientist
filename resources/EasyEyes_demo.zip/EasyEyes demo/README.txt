EasyEyes Demo

Dear colleague

EasyEyes Threshold is a compiler that converts your spreadsheet table into a web app for online vision testing. Currently it only measures spacing thresholds, for crowding research. It can measure anywhere in the visual field, radially or tangentially, with any font. It calibrates screen size, and tracks viewing distance and gaze.

TRY THE COMPILER'S ERROR CHECKING: 
The error messages are meant to be informative and helpful. Try modifying demoExperiment.xlsx, submit it to the dropbox, and look at the error messages you get from the compiler.

TEST YOURSELF OR SOMEONE YOU RECRUITED: Use demoExperiment.xlsx
1. Register for a (free) account at pavlovia.org
2. In your browser, go to http://easyeyes.app/threshold
3. Click the Pavlovia button and log in.
4. Submit all the font and form files in this demo folder into the drop box in the EasyEyes screen.
5. Submit demoExperiment.xlsx into the drop box.
6. Click the button to go to Pavlovia.
7. If you have a university license, then hit RUNNING and RUN. Otherwise hit PILOTING and PILOT, to avoid being charged by Pavlovia.
8. Perform the demo experiment.
9. Hit the download data button on the Pavlovia page to get your results.
10. Edit the demo to make it do what you want. Currently EasyEyes only measures spacing thresholds, to study crowding. We plan to add contrast thresholds, but it might take a few months as there are several technical issues to work out: gamma and dither. The EasyEyes Threshold page, above, links to the Manual and Parameter Glossary. Please only test participants after you've replaced our placeholder with your own IRB-approved consent form.

RECRUIT AND TEST ONLINE: Use recruitExperiment.xlsx
This file differs from demoExperiment.xlsx solely in having an added line setting the parameter _participantRecruitmentService to Prolific. The rest is the same. That's all you need, in your table, to use Prolific. Follow the steps above, but with the recruitExperiment table, and a new button will appear on the EasyEyes screen offering to take you to Prolific to deploy your experiment. Prolific has a Preview mode that you can use, on yourself, for free. Please only test participants after you've replaced our placeholder with your own IRB-approved consent form.

The most popular services for online recruitment are Prolific and Amazon Mechanical Turk (MTurk). EasyEyes has integrated support for Prolific to facilitate its use. Integration with MTurk is planned, as well. 

To use Prolific, you must select Pavlovia's RUNNING, not PILOTING, mode. For this, Pavlovia will require either that your university have a license, or that you put money into your Pavlovia account to pay 20 pence per participant.

Comments are very welcome. Please write to me at denis.pelli@nyu.edu with SUBJECT:EasyEyes.

Good luck!
Denis Pelli
November 22, 2021